cd $(dirname $0)
pwd
chmod +x ./bin/mac/webpinfo
chmod +x ./bin/mac/img2webp
chmod +x ./bin/mac/cwebp
java -jar java.jar
